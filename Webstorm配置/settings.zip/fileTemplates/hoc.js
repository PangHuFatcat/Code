import React, { PureComponent } from 'react'

export const ${COMPONENT_NAME} = params => WrappedComponent => class extends PureComponent {
  // 导出新的组件
  render() {
    return (
        <div>${COMPONENT_NAME}</div>
    )
  }
}