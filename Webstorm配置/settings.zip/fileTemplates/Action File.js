import { ${COMPONENT_NAME} } from '../../constants/index'

// 
export const ${COMPONENT_NAME} = action => ({
  type: ${COMPONENT_NAME},
});