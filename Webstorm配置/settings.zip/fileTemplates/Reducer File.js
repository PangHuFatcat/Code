import { ${COMPONENT_NAME} } from '../../constants/index'

export const ${COMPONENT_NAME} = (state = {}, action) => {
  switch (action.type) {
    case ${COMPONENT_NAME}: return {...state, ...action}
    default: return state
  }
}