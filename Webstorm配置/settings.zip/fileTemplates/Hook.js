import React, { useEffect } from 'react'

const ${COMPONENT_NAME} = () => {

  // 作用
  useEffect(() => {
  
  })

  // 导出JSX
  return <div>
    ${COMPONENT_NAME}
  </div>

}

export default ${COMPONENT_NAME}