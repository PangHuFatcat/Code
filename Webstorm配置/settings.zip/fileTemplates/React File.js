import React, { PureComponent } from 'react';

class ${COMPONENT_NAME} extends PureComponent {
  // 渲染JSX
  render() {
    return (
        <div>${COMPONENT_NAME}</div>
    );
  }
}

export default ${COMPONENT_NAME};