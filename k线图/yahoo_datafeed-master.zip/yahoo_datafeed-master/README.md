UDF-compatible Quandl/Yahoo datafeed
==============

This repository contains a sample implementation of server-side UDF-compatible data source.

Register for free at www.quandl.com to get your free API key.

Set QUANDL_API_KEY environment variable to your Quandl key before starting the feed.

Use NodeJS to launch yahoo.js