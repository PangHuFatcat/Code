1、安装nodejs
2、通过命令“npm install http-server -g”，安装http-server