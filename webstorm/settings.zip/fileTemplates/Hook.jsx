import React, { useEffect } from 'react'

const ${COMPONENT_NAME} = () => {

  useEffect(() => {
  
  })

  return <div>
    ${COMPONENT_NAME}
  </div>

}

export default ${COMPONENT_NAME}