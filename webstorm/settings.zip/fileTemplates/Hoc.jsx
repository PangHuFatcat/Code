import React, { PureComponent } from 'react'

export const ${COMPONENT_NAME} = params => WrappedComponent => class extends PureComponent {
 
  render() {
    return (
        <div>${COMPONENT_NAME}</div>
    )
  }
}